# css-grid-template
CSS Grid responsive layout

Maquetado responsive con CSS Grid

[![Maquetado responsive con CSS Grid](https://img.youtube.com/vi/T4t00Hd3qZc/0.jpg)](https://www.youtube.com/watch?v=T4t00Hd3qZc "Maquetado responsive con CSS Grid")

